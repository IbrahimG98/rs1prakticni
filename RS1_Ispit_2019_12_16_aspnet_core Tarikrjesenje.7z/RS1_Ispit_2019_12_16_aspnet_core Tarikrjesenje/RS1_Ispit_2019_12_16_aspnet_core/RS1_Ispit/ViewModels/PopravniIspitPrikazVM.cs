﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class PopravniIspitPrikazVM
    {
        public int PredmetID { get; set; }

        public int SkolaID { get; set; }

        public int SkolskaGodinaID { get; set; }
        public List<Row> popravniispit { get; set; }
        public class Row
        {
            public int PopravniIspitID { get; set; }

            public string DatumIspita { get; set; }

            public string Nastavnik { get; set; }

            public int brojUcenikaUkupno { get; set; }

            public int brojUcenikaKojiSuPolozili { get; set; }
        }
       
    }
}
