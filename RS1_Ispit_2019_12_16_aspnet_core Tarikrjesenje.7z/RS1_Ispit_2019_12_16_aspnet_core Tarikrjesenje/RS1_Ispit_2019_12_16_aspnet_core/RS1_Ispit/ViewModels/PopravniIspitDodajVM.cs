﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class PopravniIspitDodajVM
    {

        public List<SelectListItem> Nastavnik { get; set; }

        public int Nastavnik1ID { get; set; }
        public int Nastavnik2ID { get; set; }
        public int Nastavnik3ID { get; set; }

        public DateTime DatumIspita { get; set; }

        public int SkolaID { get; set; }

        public string Skola { get; set; }
        public int SkolskaGodinaID { get; set; }

        public string SkolskaGodina { get; set; }

        public int PredmetID { get; set; }

        public string Predmet { get; set; }
    }
}
