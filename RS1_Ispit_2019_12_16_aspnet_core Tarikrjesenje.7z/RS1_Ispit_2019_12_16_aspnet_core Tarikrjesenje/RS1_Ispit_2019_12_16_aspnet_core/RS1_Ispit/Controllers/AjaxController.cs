﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxController : Controller
    {

        private MojContext _context;

        public AjaxController(MojContext db)
        {
            _context = db;
        }
        public IActionResult Index(int PopravniIspitID)
        {
            AjaxIndexVM Model = new AjaxIndexVM
            {
                ucenici = _context.PopravniIspitStavke.Where(x => x.PopravniIspitID == PopravniIspitID).Select(k => new AjaxIndexVM.Row
                {
                    PopravniIspitStavkeID = k.ID,
                    Ucenik = _context.OdjeljenjeStavka.Include(o => o.Ucenik).Where(l => l.Id == k.OdjeljenjeStavkaID).FirstOrDefault().Ucenik.ImePrezime,
                    BrojUDnevniku = k.OdjeljenjeStavka.BrojUDnevniku,
                    Odjeljenje = _context.OdjeljenjeStavka.Include(o => o.Odjeljenje).Where(l => l.Id == k.OdjeljenjeStavkaID).FirstOrDefault().Odjeljenje.Oznaka,
                    Bodovi = k.Bodovi,
                    Prisutpio = k.PristupioIspitu
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult UcenikJePrisutan(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke pis = _context.PopravniIspitStavke.Find(PopravniIspitStavkeID);

            pis.PristupioIspitu = true;
            _context.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID="+ pis.PopravniIspitID);
        }

        public IActionResult Uredi(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke pis = _context.PopravniIspitStavke.Find(PopravniIspitStavkeID);

            AjaxUrediVM Model = new AjaxUrediVM
            {
                PopravniIspitStavkeID = PopravniIspitStavkeID,
                Ucenik = _context.OdjeljenjeStavka.Include(o => o.Ucenik).Where(l => l.Id == pis.OdjeljenjeStavkaID).FirstOrDefault().Ucenik.ImePrezime,
                Bodovi = pis.Bodovi
            };
            return PartialView(Model);
        }

        public IActionResult Snimi(AjaxUrediVM x)
        {

            PopravniIspitStavke p = _context.PopravniIspitStavke.Find(x.PopravniIspitStavkeID);

            p.Bodovi = x.Bodovi;
            _context.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID="+p.PopravniIspitID);
        }
    }
}