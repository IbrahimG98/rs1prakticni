﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class PopravniIspitController : Controller
    {

        private MojContext _context;

        public PopravniIspitController(MojContext db)
        {
            _context = db;
        }
        public IActionResult Index()
        {

            PopravniIspitIndexVM Model = new PopravniIspitIndexVM
            {
                predmeti = _context.Predmet.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                skolskaGodina = _context.SkolskaGodina.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList(),
                skole = _context.Skola.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Naziv
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Prikaz(PopravniIspitIndexVM x)
        {

            PopravniIspitPrikazVM Model = new PopravniIspitPrikazVM
            {
                SkolaID = x.SkolaID,
                PredmetID = x.PredmetID,
                SkolskaGodinaID = x.SkolskaGodinaID,
                popravniispit = _context.PopravniIspit.Include(o => o.Nastavnik1).Where(l => l.PredmetID == x.PredmetID).Select(k => new PopravniIspitPrikazVM.Row
                {
                    PopravniIspitID = k.ID,
                    Nastavnik = k.Nastavnik1.Ime + " " + k.Nastavnik1.Prezime,
                    brojUcenikaUkupno = _context.PopravniIspitStavke.Count(l => l.PopravniIspitID == k.ID),
                    brojUcenikaKojiSuPolozili = _context.PopravniIspitStavke.Count(l => l.PopravniIspitID == k.ID && l.Bodovi > 50),
                    DatumIspita = k.DatumIspita.ToShortDateString()

                }).ToList()
            };
            return View(Model);
        }


        public IActionResult Dodaj(int PredmetID,int SkolskaGodinaID,int SkolaID)
        {
            PopravniIspitDodajVM Model = new PopravniIspitDodajVM
            {
                Predmet = _context.Predmet.Where(k => k.Id == PredmetID).FirstOrDefault().Naziv,
                Skola = _context.Skola.Where(k => k.Id == SkolaID).FirstOrDefault().Naziv,
                SkolskaGodina = _context.SkolskaGodina.Where(k => k.Id == SkolskaGodinaID).FirstOrDefault().Naziv,
                PredmetID = PredmetID,
                SkolaID =SkolaID,
                SkolskaGodinaID =SkolskaGodinaID,
                //Nastavnik = _context.PredajePredmet.Include(o => o.Odjeljenje).Where(k => k.Odjeljenje.SkolaID == SkolaID).Select(l => new SelectListItem
                //{
                //    Value = l.Nastavnik.Id.ToString(),
                //    Text = l.Nastavnik.Ime + " " + l.Nastavnik.Prezime
                //}).ToList(),
                Nastavnik = _context.Nastavnik.Where(l => l.SkolaID == SkolaID).Select(k => new SelectListItem
                {
                    Value = k.Id.ToString(),
                    Text = k.Ime+" "+k.Prezime
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Snimi(PopravniIspitDodajVM x)
        {
            PopravniIspit p = new PopravniIspit
            {
                DatumIspita = x.DatumIspita,
                SkolaID = x.SkolaID,
                PredmetID = x.PredmetID,
                SkolaskGodinaID = x.SkolskaGodinaID,
                Nastavnik1ID = x.Nastavnik1ID,
                Nastavnik2ID = x.Nastavnik2ID,
                Nastavnik3ID = x.Nastavnik3ID
            };

            _context.PopravniIspit.Add(p);
            _context.SaveChanges();


            foreach (OdjeljenjeStavka k in _context.OdjeljenjeStavka.Include(t => t.Odjeljenje).Where(l => l.Odjeljenje.SkolaID == x.SkolaID && l.Odjeljenje.SkolskaGodinaID == x.SkolskaGodinaID))
            {
                if(_context.DodjeljenPredmet.Where(l => l.OdjeljenjeStavkaId == k.Id && l.PredmetId == p.PredmetID).FirstOrDefault() != null &&  _context.DodjeljenPredmet.FirstOrDefault(l => l.OdjeljenjeStavkaId == k.Id && l.PredmetId == p.PredmetID).ZakljucnoKrajGodine == 1)
                {
                    PopravniIspitStavke pis = new PopravniIspitStavke
                    {
                        OdjeljenjeStavka = k,
                        PopravniIspit = p,
                     
                        PristupioIspitu = false,

                    };

                    if (_context.DodjeljenPredmet.Where(u => u.OdjeljenjeStavkaId == k.Id).Count(t => t.ZakljucnoKrajGodine == 1) > 2)
                    {
                        pis.Bodovi = 0;
                    }
                    else
                    {
                        pis.Bodovi = null;
                    }
                   
                    _context.PopravniIspitStavke.Add(pis);
                }
            }

           
            _context.SaveChanges();
            return Redirect("/PopravniIspit/Prikaz");
        }

        public IActionResult Uredi(int PopravniIspitID)
        {
            PopravniIspit p = _context.PopravniIspit.Include(l => l.Nastavnik1)

                                                        .Include(l => l.Nastavnik2)
                                                        .Include(l => l.Nastavnik3)
                                                         .Include(l => l.Skola)
                                                          .Include(l => l.SkolaskGodina)
                                                           .Include(l => l.Predmet)
                                                    .Where(x => x.ID == PopravniIspitID).FirstOrDefault();
            PopravniIspitUrediVM Model = new PopravniIspitUrediVM
            {
                Nastavnik1 = p.Nastavnik1.Ime + " " + p.Nastavnik1.Prezime,
                Nastavnik2 = p.Nastavnik2.Ime + " " + p.Nastavnik2.Prezime,
                Nastavnik3 = p.Nastavnik3.Ime + " " + p.Nastavnik3.Prezime,
                Skola = p.Skola.Naziv,
                SkolskaGodina = p.SkolaskGodina.Naziv,
                Predmet = p.Predmet.Naziv,
                PopravniIspitID = PopravniIspitID,
                DatumIspita = p.DatumIspita.ToShortDateString()

            };
            return View(Model);
        }
      
    }
}