﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class PopravniIspitController : Controller
    {
        private MojContext _db;
        public PopravniIspitController(MojContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            PopravniIspitIndexVM Model = new PopravniIspitIndexVM
            {
                rows = _db.Odjeljenje.Select(x => new PopravniIspitIndexVM.Row
                {
                    OdjeljenjeID = x.Id,
                    Skola = x.Skola.Naziv,
                    SkolskaGodina = x.SkolskaGodina.Naziv,
                    OznakaOdjeljenja = x.Oznaka
                }).OrderBy(l=>l.SkolskaGodina).ToList()

            };
            return View(Model);
        }
        public IActionResult Odaberi(int OdjeljenjeID)
        {
            Odjeljenje o = _db.Odjeljenje.Where(x => x.Id == OdjeljenjeID).FirstOrDefault();

            PopravniIspitOdaberiVM Model = new PopravniIspitOdaberiVM
            {
                OdjeljenjeID = o.Id,
                rows = _db.PopravniIspit.Where(x => x.OdjeljenjeID == o.Id).Select(j => new PopravniIspitOdaberiVM.Row
                {
                    PopravniIspitID = j.ID,
                    Datum = j.DatumIspita.ToShortDateString(),
                    Predmet = j.Predmet.Naziv,
                    BrojUcenikaNaPopravnom = _db.PopravniIspitStavke.Count(x => x.PopravniIspitID == j.ID),
                    BrojUcenikaKojiSuPolozili = _db.PopravniIspitStavke.Count(x => x.PopravniIspitID == j.ID && x.RezultatMaturskog > 50)

                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Dodaj(int OdjeljenjeID)
        {
            Odjeljenje o = _db.Odjeljenje.Include(n=>n.Skola).Include(m=>m.SkolskaGodina).Where(x => x.Id == OdjeljenjeID).FirstOrDefault();

            PopravniIspitDodajVM Model = new PopravniIspitDodajVM
            {
                OdjeljenjeID=o.Id,
                Predmet=_db.Predmet.Where(x=>x.Razred==o.Razred).Select(k=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value=k.Id.ToString(),
                    Text=k.Naziv

                }).ToList(),
                Skola=o.Skola.Naziv,
                SkolskaGodina=o.SkolskaGodina.Naziv,
                OznakaOdjeljenja=o.Oznaka
            };
            return View(Model);
        }
        public IActionResult Snimi(PopravniIspitDodajVM x)
        {
            PopravniIspit i = new PopravniIspit
            {
                DatumIspita = x.Datum,
                OdjeljenjeID = x.OdjeljenjeID,
                PredmetID = x.PredmetID
            };
            _db.PopravniIspit.Add(i);
            _db.SaveChanges();

            foreach(var m in _db.OdjeljenjeStavka.Where(j=>j.OdjeljenjeId==i.OdjeljenjeID))
            {
                if(_db.DodjeljenPredmet.Where(l=>l.OdjeljenjeStavkaId==m.Id && l.PredmetId==i.PredmetID).Count(v=>v.ZakljucnoKrajGodine==1)==1)
                {
                    PopravniIspitStavke pis = new PopravniIspitStavke
                    {
                        OdjeljenjeStavkaID = m.Id,
                        PopravniIspitID = i.ID,
                        Pristupio = false
                    };

                    if(_db.DodjeljenPredmet.Where(l => l.OdjeljenjeStavkaId == m.Id ).Count(v => v.ZakljucnoKrajGodine == 1) >2)
                    {
                        pis.RezultatMaturskog = 0;
                    }
                    else
                    {
                        pis.RezultatMaturskog = null;
                    }
                    _db.PopravniIspitStavke.Add(pis);
                }
            }
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Odaberi?OdjeljenjeID="+i.OdjeljenjeID);
        }

        public IActionResult Uredi(int PopravniIspitID)
        {
            PopravniIspit p = _db.PopravniIspit.Include(c=>c.Predmet).Include(l=>l.Odjeljenje)
                .Include(m=>m.Odjeljenje.Skola).Include(k=>k.Odjeljenje.SkolskaGodina).Where(x => x.ID == PopravniIspitID).FirstOrDefault();
            PopravniIspitUrediVM Model = new PopravniIspitUrediVM
            {
                PopravniIspitID=p.ID,
                Datum=p.DatumIspita.ToShortDateString(),
                Skola=p.Odjeljenje.Skola.Naziv,
                SkolskaGodina=p.Odjeljenje.SkolskaGodina.Naziv,
                OdjeljenjeOznaka=p.Odjeljenje.Oznaka,
                Predmet=p.Predmet.Naziv

            };
            return View(Model);
        }
    }
}