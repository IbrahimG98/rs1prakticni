﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxStavkeController : Controller
    {
        private MojContext _db;
        public AjaxStavkeController(MojContext db)
        {
            _db = db;
        }
        public IActionResult Index(int PopravniIspitID)
        {
            PopravniIspit i = _db.PopravniIspit.Include(b=>b.Odjeljenje).Where(x => x.ID == PopravniIspitID).FirstOrDefault();
            AjaxStavkeIndexVM Model = new AjaxStavkeIndexVM
            {
                PopravniIspitID=PopravniIspitID,
                rows=_db.PopravniIspitStavke.Include(v=>v.OdjeljenjeStavka.Odjeljenje).Include(c=>c.OdjeljenjeStavka.Ucenik).Where(x=>x.PopravniIspitID==i.ID).Select(k=>new AjaxStavkeIndexVM.Row
                {
                    PopravniIspitStavkeID=k.ID,
                   ///* UcenikImePrezime=_db.OdjeljenjeStavka.Where(m=>m.Id==k.OdjeljenjeStavkaID).Select(n=>n.Ucenik.ImePrezime).FirstOrDefault()*/,
                    UcenikImePrezime=k.OdjeljenjeStavka.Ucenik.ImePrezime,
                    BrojUDnevniku=k.OdjeljenjeStavka.BrojUDnevniku,
                    Odjeljenje=k.OdjeljenjeStavka.Odjeljenje.Oznaka,
                    RezultatMaturskog=k.RezultatMaturskog,
                    Pristupio=k.Pristupio
                }).ToList()

            };
            return PartialView(Model);
        }
        public IActionResult Pristupio(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke p = _db.PopravniIspitStavke.Find(PopravniIspitStavkeID);
            if (p.Pristupio == true)
                p.Pristupio = false;
            else
                p.Pristupio = true;
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID="+p.PopravniIspitID);
        }
        public IActionResult Uredi(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke p = _db.PopravniIspitStavke.Include(m=>m.OdjeljenjeStavka.Ucenik).Where(x => x.ID == PopravniIspitStavkeID).FirstOrDefault();
            AjaxStavkeUrediVM Model = new AjaxStavkeUrediVM
            {
                PopravniIspitStavkeID = p.ID,
                UcenikImePrezime = p.OdjeljenjeStavka.Ucenik.ImePrezime,
                RezultatMaturskog = p.RezultatMaturskog
            };
            return PartialView(Model);
        }
        public IActionResult SnimiUredi(AjaxStavkeUrediVM x)
        {
            PopravniIspitStavke p = _db.PopravniIspitStavke.Find(x.PopravniIspitStavkeID);
            p.RezultatMaturskog = x.RezultatMaturskog;
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID=" + p.PopravniIspitID);
        }
        public IActionResult SnimiRezultat(int PopravniIspitStavkeID,int Rezultat)
        {
            PopravniIspitStavke p = _db.PopravniIspitStavke.Find(PopravniIspitStavkeID);
            p.RezultatMaturskog = Rezultat;
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID=" + p.PopravniIspitID);
        }
    }
}