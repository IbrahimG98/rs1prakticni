﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class Ucenik
    {
        public int Id { get; set; }
        public string ImePrezime { get; set; }
    }
}
