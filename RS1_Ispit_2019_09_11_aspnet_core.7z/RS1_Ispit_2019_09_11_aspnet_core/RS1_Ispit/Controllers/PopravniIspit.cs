﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;


namespace RS1_Ispit_asp.net_core.Controllers
{
    public class PopravniIspit : Controller
    {

       private MojContext _db;

      public PopravniIspit(MojContext db)
        {
            _db = db;
        }


       
    }
}