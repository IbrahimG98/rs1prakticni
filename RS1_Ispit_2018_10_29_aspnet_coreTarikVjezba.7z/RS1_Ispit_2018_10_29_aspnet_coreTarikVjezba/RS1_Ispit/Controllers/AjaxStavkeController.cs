﻿using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxStavkeController:Controller
    {
        private MojContext _db;
        public AjaxStavkeController(MojContext db)
        {
            _db = db;
        }
       public IActionResult Index(int CasID)
        {
            Cas c = _db.Cas.Find(CasID);
            AjaxStavkeIndexVM Model = new AjaxStavkeIndexVM
            {
                CasID = c.ID,
                rows = _db.CasStavka.Where(x => x.CasID == c.ID).Select(k => new AjaxStavkeIndexVM.Row {
                    CasStavkeID = k.ID,
                    UcenikImePrezime = _db.OdjeljenjeStavka.Where(l => l.Id == k.OdjeljenjeStavkaID).Select(z => z.Ucenik.ImePrezime).FirstOrDefault(),
                    Ocjena = k.Ocjena,
                    OpravdanoOdustan = k.OpravdanoOdsutan,
                    Prisutan = k.Prisutan
                }).ToList()

            };

            return PartialView(Model);
        }

        public IActionResult Prisutan(int CasStavkeID)
        {
            CasStavka s = _db.CasStavka.Find(CasStavkeID);
            s.Prisutan = true;
            _db.SaveChanges();
            return Redirect("/OdrzanaNastava/Uredi?CasID="+s.CasID);
        }

    }
}
