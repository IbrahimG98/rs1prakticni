﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class OdrzanaNastavaController : Controller
    {
        private MojContext _db;
        public OdrzanaNastavaController(MojContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            OdrzanaNastavaIndexVM Model = new OdrzanaNastavaIndexVM {
                rows=_db.Nastavnik.Select(x=>new OdrzanaNastavaIndexVM.Rows {
                    NastavnikID=x.Id,
                    NastavnikImePrezime=x.Ime+" "+x.Prezime,
                    SkolaNaziv=x.Skola.Naziv
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Odaberi(int NastavnikID)
        {
            Nastavnik n = _db.Nastavnik.Include(h=>h.Skola).Where(x => x.Id == NastavnikID).FirstOrDefault();
            //include?
            OdrzanaNastavaOdaberiVM Model = new OdrzanaNastavaOdaberiVM
            {
                NastavnikID = n.Id,
                NastavnikImePrezime = n.Ime + " " + n.Prezime,
                SkolaNaziv = n.Skola.Naziv,
                rows = _db.Cas.Include(h=>h.PredajePredmet).Where(l => l.NastavnikID == n.Id && l.Nastavnik.SkolaID == n.SkolaID).Select(g => new OdrzanaNastavaOdaberiVM.Rows
                {
                    CasID = g.ID,
                    Datum = g.Datum.ToShortDateString(),
                    //Odjeljenje = _db.PredajePredmet.Include(h=>h.Odjeljenje).Where(m => m.NastavnikID == n.Id && m.Nastavnik.SkolaID == n.SkolaID).FirstOrDefault().
                    //Odjeljenje.SkolskaGodina.Naziv +
                    //        "/" + _db.PredajePredmet.Where(m => m.NastavnikID == n.Id && m.Nastavnik.SkolaID == n.SkolaID).FirstOrDefault().Odjeljenje.Oznaka,
                    Odjeljenje=_db.Odjeljenje.Include(a=>a.SkolskaGodina).Where(h=>h.SkolaID==n.SkolaID).FirstOrDefault().SkolskaGodina.Naziv+"/"+
                    _db.Odjeljenje.Where(h => h.SkolaID == n.SkolaID).FirstOrDefault().Oznaka,

                    Predmet = _db.PredajePredmet.Include(h=>h.Predmet).Where(h => h.Id == g.PredajePredmetID).FirstOrDefault().Predmet.Naziv,
                    Ucenici=_db.CasStavka.Include(h=>h.OdjeljenjeStavka).Where(j=>j.CasID==g.ID && j.Prisutan==false).Select(v=>v.OdjeljenjeStavka.Ucenik.ImePrezime).ToList()

                }).ToList()

            };
            return View(Model);
        }

        public IActionResult Dodaj(int NastavnikID)
        {
            Nastavnik n = _db.Nastavnik.Where(m => m.Id == NastavnikID).FirstOrDefault();
            OdrzanaNastavaDodajVM Model = new OdrzanaNastavaDodajVM
            {
                NastavnikID = n.Id,
                NastavnikImePrezime = n.Ime +" "+n.Prezime,
                predajepredmet=_db.PredajePredmet.Where(u=>u.NastavnikID==n.Id && u.Odjeljenje.SkolaID==n.SkolaID).Select(i=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem {
                    Value=i.Id.ToString(),
                    Text=i.Odjeljenje.Oznaka+"/"+i.Predmet.Naziv
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Snimi(OdrzanaNastavaDodajVM x)
        {
            Cas cas = new Cas
            {
                Datum = x.Datum,
                NastavnikID = x.NastavnikID,
                PredajePredmetID = x.PredajePredmetID
            };
            _db.Cas.Add(cas);
            _db.SaveChanges();

            foreach (var i in _db.OdjeljenjeStavka.Include(k=>k.Odjeljenje).Where(z=>z.OdjeljenjeId==_db.PredajePredmet.Where(u=>u.Id==cas.PredajePredmetID).FirstOrDefault().OdjeljenjeID && 
             z.Odjeljenje.SkolaID==_db.PredajePredmet.Include(n=>n.Odjeljenje).Where(f=>f.NastavnikID==cas.NastavnikID).FirstOrDefault().Odjeljenje.SkolaID))
            {
                CasStavka cs = new CasStavka
                {
                    CasID = cas.ID,
                    OdjeljenjeStavkaID = i.Id,
                    Ocjena = 0,
                    Prisutan = false,
                    OpravdanoOdsutan = false
                };
                _db.CasStavka.Add(cs);

            }
            _db.SaveChanges();

            return Redirect("/OdrzanaNastava/Odaberi?NastavnikID="+cas.NastavnikID);
        }

        public IActionResult Uredi(int CasID)
        {
            Cas c = _db.Cas.Find(CasID);
            OdrzanaNastavaUrediVM Model = new OdrzanaNastavaUrediVM
            {
                CasID=c.ID,
                Datum=c.Datum.ToShortDateString(),
                OdjeljenjePredmet=_db.PredajePredmet.Include(j=>j.Odjeljenje).Where(x=>x.Id==c.PredajePredmetID).FirstOrDefault().Odjeljenje.Oznaka+"/"+
                _db.PredajePredmet.Include(z=>z.Predmet).Where(x => x.Id == c.PredajePredmetID).FirstOrDefault().Predmet.Naziv,
                SadrzajCasa=c.SadrzajCasa
            };
            
            return View(Model);
        }
        public IActionResult UrediSnimi(OdrzanaNastavaUrediVM u)
        {
            Cas c = _db.Cas.Find(u.CasID);
            c.SadrzajCasa = u.SadrzajCasa;
            _db.SaveChanges();
            return Redirect("/OdrzanaNastava/Odaberi?NastavnikID="+c.NastavnikID);
        }

    }
}