﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class OdrzanaNastavaOdaberiVM
    {
        public int NastavnikID { get; set; }
        public string NastavnikImePrezime { get; set; }
        public string SkolaNaziv { get; set; }
        public List<Rows> rows { get; set; }
        public class Rows
        {
            public int CasID { get; set; }
            public string Datum { get; set; }
            public string Odjeljenje { get; set; }
            public List<string> Ucenici { get; set; }
            public string Predmet { get; set; }
        }
    }
}
