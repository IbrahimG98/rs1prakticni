﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace RS1_Ispit_asp.net_core.Migrations
{
    public partial class DodajCasuCasStavka : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CasID",
                table: "CasStavka",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_CasStavka_CasID",
                table: "CasStavka",
                column: "CasID");

            migrationBuilder.AddForeignKey(
                name: "FK_CasStavka_Cas_CasID",
                table: "CasStavka",
                column: "CasID",
                principalTable: "Cas",
                principalColumn: "ID",
                onDelete: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CasStavka_Cas_CasID",
                table: "CasStavka");

            migrationBuilder.DropIndex(
                name: "IX_CasStavka_CasID",
                table: "CasStavka");

            migrationBuilder.DropColumn(
                name: "CasID",
                table: "CasStavka");
        }
    }
}
