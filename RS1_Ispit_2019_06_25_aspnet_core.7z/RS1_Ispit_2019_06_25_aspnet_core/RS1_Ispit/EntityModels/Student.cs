﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class Student
    {
        public int Id { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string BrojIndeksa { get; set; }

    }
}
