﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxController : Controller
    {

        private MojContext _context;

        public AjaxController(MojContext db)
        {
            _context = db;
        }
        public IActionResult Index(int IspitID)
        {
            Ispit i = _context.Ispit.Find(IspitID);
            AjaxIndexVM Model = new AjaxIndexVM
            {
                IspitID = IspitID,
                Datum = DateTime.Now > i.DatumIspita ? true : false,
                studenti = _context.IspitStavke.Where(x => x.IspitID == IspitID).Select(k => new AjaxIndexVM.Row
                {
                    IspitStavkeID = k.ID,
                    Student = k.Student.Ime + " " + k.Student.Prezime,
                    Ocjena = k.Ocjena,
                    Pristupio = k.Pristupio
                }).ToList()
            };
            return PartialView(Model);
        }

        public IActionResult Pristupio(int IspitStavkeID)
        {

            IspitStavke iss = _context.IspitStavke.Find(IspitStavkeID);
            if (iss.Pristupio)
                iss.Pristupio = false;
            else
                iss.Pristupio = true;

            _context.SaveChanges();
            return Redirect("/Ispit/Detalji?IspitID="+iss.IspitID);
        }

        public IActionResult Uredi(int IspitStavkeID)
        {

            IspitStavke iss = _context.IspitStavke.Include(k => k.Student).Where(l => l.ID == IspitStavkeID).FirstOrDefault();

            AjaxUrediVM Model = new AjaxUrediVM
            {
                IspitStavkeID = iss.ID,
                Student = iss.Student.Ime + " " + iss.Student.Prezime,
                Ocjena = iss.Ocjena
            };
            return PartialView(Model);
        }

        public IActionResult Snimi(AjaxUrediVM x)
        {
            IspitStavke iss = _context.IspitStavke.Find(x.IspitStavkeID);

            iss.Ocjena = x.Ocjena;
            _context.SaveChanges();

            return Redirect("/Ispit/Detalji?IspitID=" + iss.IspitID);
        }

        public IActionResult SnimiOcjenu(int IspitStavkeID, int Ocjena)
        {
            IspitStavke iss = _context.IspitStavke.Find(IspitStavkeID);

            iss.Ocjena = Ocjena;
            _context.SaveChanges();

            return Redirect("/Ispit/Detalji?IspitID=" + iss.IspitID);
        }
    }
}