﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class IspitController : Controller
    {

        private MojContext _context;

        public IspitController(MojContext db)
        {
            _context = db;
        }
        public IActionResult Index()
        {
            IspitIndexVM Model = new IspitIndexVM
            {
                ispiti = _context.Angazovan.Select(x => new IspitIndexVM.Row
                {
                    AngazovanID = x.Id,
                    AkademskaGodina = x.AkademskaGodina.Opis,
                    Nastavnik = x.Nastavnik.Ime + " " + x.Nastavnik.Prezime,
                    BrojOdrzanihCasova = _context.OdrzaniCas.Count(l => l.AngazovaniId == x.Id),
                    BrojStudenataNaPredmetu = _context.SlusaPredmet.Count(l => l.AngazovanId == x.Id),
                    NazivPredmeta = x.Predmet.Naziv
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Odaberi(int AngazovanID)
        {

            Angazovan a = _context.Angazovan.Where(l => l.Id == AngazovanID).FirstOrDefault();

            IspitIOdaberiVM Model = new IspitIOdaberiVM
            {
                AngazovanID = a.Id,
                ispiti = _context.Ispit.Where(l => l.AngazovanID == a.Id).Select(k => new IspitIOdaberiVM.Row
                {
                    IspitID = k.ID,
                    DatumIspit = k.DatumIspita.ToShortDateString(),
                    BrojPrijavljenih = _context.IspitStavke.Count(x => x.IspitID == k.ID),
                    BrojStudenataKojiNisuPolozili = _context.IspitStavke.Count(x => x.IspitID == k.ID && x.Ocjena == 5),
                    Zakljucano = k.Zakljucan
                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Dodaj(int AngazovanID)
        {
            Angazovan a = _context.Angazovan.Include(k => k.Predmet).Include(k => k.AkademskaGodina).Include(k => k.Nastavnik).Where(l => l.Id == AngazovanID).FirstOrDefault();

            IspitDodajVM Model = new IspitDodajVM
            {
                AngazovanID = a.Id,
                Predmet = a.Predmet.Naziv,
                SkolskaGodina = a.AkademskaGodina.Opis,
                Nastavnik = a.Nastavnik.Ime + " " + a.Nastavnik.Prezime,

            };
            return View(Model);
        }

        public IActionResult Snimi(IspitDodajVM x)
        {
            Ispit i = new Ispit
            {
                AngazovanID = x.AngazovanID,
                DatumIspita = x.Datum,
                Napomena = x.Napomena,
                Zakljucan = false
            };

            _context.Ispit.Add(i);
            _context.SaveChanges();

            foreach (var k in _context.SlusaPredmet.Include(t => t.UpisGodine).Where(l => l.AngazovanId == i.AngazovanID))
            {
                IspitStavke iss = new IspitStavke
                {
                    Ispit = i,
                    StudentID = k.UpisGodine.StudentId,
                    Pristupio = false,
                    Ocjena = 0,

                };

                _context.IspitStavke.Add(iss);
            }

            _context.SaveChanges();

            return Redirect("/Ispit/Odaberi?AngazovanID="+i.AngazovanID);
        }

        public IActionResult Zakljucaj(int IspitID)
        {
            Ispit i = _context.Ispit.Find(IspitID);

            i.Zakljucan = true;
            _context.SaveChanges();

            return Redirect("/Ispit/Odaberi?AngazovanID=" + i.AngazovanID);
        }

        public IActionResult Detalji(int IspitID)
        {

            Ispit i = _context.Ispit.Include(l => l.Angazovan).Include(t => t.Angazovan.AkademskaGodina)
                                                                .Include(t => t.Angazovan.Nastavnik)
                                                                .Include(t => t.Angazovan.Predmet)
                                                                .Where(k => k.ID == IspitID).FirstOrDefault();

            IspitDetaljiVM Model = new IspitDetaljiVM
            {
                IspitID = i.ID,
               // Predmet = _context.Angazovan.Where(l => l.PredmetId == i.Angazovan.PredmetId).Select(l => l.Predmet.Naziv).FirstOrDefault(),
               Predmet = i.Angazovan.Predmet.Naziv,
                SkolskaGodina = i.Angazovan.AkademskaGodina.Opis,
                Nastavnik = i.Angazovan.Nastavnik.Ime + " " + i.Angazovan.Nastavnik.Prezime,
                Napomena = i.Napomena,
                Datum = i.DatumIspita.ToShortDateString()
            };
            return View(Model);
        }
    }
}