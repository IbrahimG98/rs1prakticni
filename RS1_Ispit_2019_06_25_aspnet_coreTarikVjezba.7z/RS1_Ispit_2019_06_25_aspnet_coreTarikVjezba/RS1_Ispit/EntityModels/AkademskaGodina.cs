﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class AkademskaGodina
    {
        public int Id { get; set; }
        public string Opis { get; set; }
    }
}
