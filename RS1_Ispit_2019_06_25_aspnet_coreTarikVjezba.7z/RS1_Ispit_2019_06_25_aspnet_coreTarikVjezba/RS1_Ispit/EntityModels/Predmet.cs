﻿namespace RS1_Ispit_asp.net_core.EntityModels
{
    public class Predmet
    {
        public int Id { get; set; }
        public int Sifra { get; set; }
        public string Naziv { get; set; }
        public int ECTS { get; set; }

        public int Godina { get; set; }
    }
}
