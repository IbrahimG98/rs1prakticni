﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class IspitIOdaberiVM
    {

        public int AngazovanID { get; set; }


        public List<Row> ispiti { get; set; }
        public class Row
        {
            public int IspitID { get; set; }

            public string DatumIspit { get; set; }

            public int BrojStudenataKojiNisuPolozili { get; set; }

            public int BrojPrijavljenih { get; set; }

            public bool Zakljucano { get; set; }
        }
       
    }
}
