﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxStavkeController : Controller
    {
        private MojContext _db;
        public AjaxStavkeController(MojContext db)
        {
            _db = db;
        }

        public IActionResult Index(int PopravniIspitID)
        {
            PopravniIspit p = _db.PopravniIspit.Find(PopravniIspitID);
            AjaxStavkeIndexVM Model = new AjaxStavkeIndexVM
            {
                PopravniIspitID = p.ID,
                rows = _db.PopravniIspitStavke.Include(n=>n.OdjeljenjeStavka).Include(l=>l.PopravniIspit).Where(x => x.PopravniIspitID == p.ID).Select(v => new AjaxStavkeIndexVM.Rows
                {
                    PopravniIspitStavkeID=v.ID,
                    UcenikIme=v.OdjeljenjeStavka.Ucenik.ImePrezime,
                    BrojUDnevniku=v.OdjeljenjeStavka.BrojUDnevniku,
                    Odjeljenje=v.OdjeljenjeStavka.Odjeljenje.Oznaka,
                    Pristupio=v.Pirstupio,
                    RezultatMaturskog=v.RezultatMaturskog
                }).ToList()
            };
            return PartialView(Model);
        }
        public IActionResult Uredi(int popravniispitstavkeid)
        {
            PopravniIspitStavke popravniIspitStavke = _db.PopravniIspitStavke.Where(x=>x.ID==popravniispitstavkeid).FirstOrDefault();
            AjaxStavkeUrediVM Model = new AjaxStavkeUrediVM
            {
                PopravniIspitStavkeID=popravniIspitStavke.ID,
                UcenikNaziv=_db.OdjeljenjeStavka.Where(p=>p.Id==popravniIspitStavke.OdjeljenjeStavkaID).Select(h=>h.Ucenik.ImePrezime).FirstOrDefault(),
                Bodovi=popravniIspitStavke.RezultatMaturskog

            };
            return PartialView(Model);
        }

        public IActionResult Snimi(AjaxStavkeUrediVM x)
        {
            PopravniIspitStavke k = _db.PopravniIspitStavke.Find(x.PopravniIspitStavkeID);
            k.RezultatMaturskog = x.Bodovi;
            _db.SaveChanges();

            return Redirect("/PopravniIspit/Uredi?PopravniIspitID="+k.PopravniIspitID);
        }

        public IActionResult Pristupio(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke p = _db.PopravniIspitStavke.Find(PopravniIspitStavkeID);
            p.Pirstupio = true;
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID=" + p.PopravniIspitID);
        }
    }
}