﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class PopravniIspitController : Controller
    {
        private MojContext _db;
        public PopravniIspitController(MojContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            PopravniIspitIndexVM Model = new PopravniIspitIndexVM
            {
                rows = _db.Predmet.Select(x => new PopravniIspitIndexVM.Rows
                {
                    PredmetID = x.Id,
                    PredmetNaziv = x.Naziv,
                    Razred = x.Razred
                }).OrderBy(j=>j.Razred).ToList()

            };
            return View(Model);
        }

        public IActionResult Odaberi(int PredmetID)
        {
            Predmet p = _db.Predmet.Where(x => x.Id == PredmetID).FirstOrDefault();
            PopravniIspitOdaberiVM Model = new PopravniIspitOdaberiVM
            {
                PredmetID=p.Id,
                rows=_db.PopravniIspit.Where(x=>x.PredmetID==p.Id).Select(o=>new PopravniIspitOdaberiVM.Rows
                {
                    PopravniIspitID=o.ID,
                    Datum=o.DatumIspita.ToShortDateString(),
                    Skola=o.Skola.Naziv,
                    SkolskaGodina=o.SkolskaGodina.Naziv,
                    BrojUcenikaNaPopravnom=_db.PopravniIspitStavke.Count(x=>x.PopravniIspitID==o.ID),
                    BrojUcenikaKojiSuPolozili= _db.PopravniIspitStavke.Count(x => x.PopravniIspitID == o.ID && x.RezultatMaturskog>50)

                }).ToList()
            };
            return View(Model);
        }

        public IActionResult Dodaj(int PredmetID)
        {
            Predmet p = _db.Predmet.Where(x => x.Id == PredmetID).FirstOrDefault();
            PopravniIspitDodajVM Model = new PopravniIspitDodajVM
            {
                PredmetID=p.Id,
                NazivPredmeta=p.Naziv,
                Razred = p.Razred,
                Skole =_db.Skola.Select(x=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value=x.Id.ToString(),
                    Text=x.Naziv
                }).ToList(),
                SkolskaGodina=_db.SkolskaGodina.Select(x=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                {
                    Value=x.Id.ToString(),
                    Text=x.Naziv
                }).ToList()
                

            };


            return View(Model);
        }

        public IActionResult Snimi(PopravniIspitDodajVM x)
        {
            PopravniIspit m = new PopravniIspit();
            m.PredmetID = x.PredmetID;
            m.SkolskaGodinaID = x.SkolskaGodinaID;
            m.SkolaID = x.SkolaID;
            m.DatumIspita = x.DatumIspita;
            _db.PopravniIspit.Add(m);
            _db.SaveChanges();

            var SviPredmeti = _db.DodjeljenPredmet.ToList();
            foreach(var k in SviPredmeti)
            {
                var brojNegZakljucnih = _db.DodjeljenPredmet.Where(n => n.OdjeljenjeStavkaId == k.OdjeljenjeStavkaId && n.PredmetId == m.PredmetID && n.ZakljucnoKrajGodine == 1).Count();
                if (brojNegZakljucnih >= 3)
                {
                    PopravniIspitStavke pis = new PopravniIspitStavke
                    {
                        OdjeljenjeStavkaID = k.OdjeljenjeStavkaId,
                        Pirstupio = false,
                        PopravniIspitID = m.ID,
                        RezultatMaturskog = 0
                    };
                    _db.PopravniIspitStavke.Add(pis);
                }
                if (_db.OdjeljenjeStavka.Where(j => j.Id == k.OdjeljenjeStavkaId && k.ZakljucnoKrajGodine == 1 && k.PredmetId == m.PredmetID).Any())
                {
                    PopravniIspitStavke pis = new PopravniIspitStavke
                    {
                        OdjeljenjeStavkaID = k.OdjeljenjeStavkaId,
                        Pirstupio = false,
                        PopravniIspitID = m.ID,
                        RezultatMaturskog = null
                    };
                    _db.PopravniIspitStavke.Add(pis);
                }

            }
           
          
           
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Odaberi?PredmetID="+x.PredmetID);
        }

        public IActionResult Uredi(int PopravniIspitID)
        {
            PopravniIspit p = _db.PopravniIspit.Include(m=>m.Skola).Include(k=>k.Predmet).Include(l=>l.SkolskaGodina).Where(m=>m.ID==PopravniIspitID).FirstOrDefault();
            PopravniIspitUrediVM Model = new PopravniIspitUrediVM
            {
                PopravniIspitID=p.ID,
               PredmetID=p.PredmetID,
                SkolaNaziv = p.Skola.Naziv,
                SkolskaGodina = p.SkolskaGodina.Naziv,
                DatumIspita = p.DatumIspita.ToShortDateString(),
                PredmetNaziv = p.Predmet.Naziv,
                Razred = p.Predmet.Razred


            };
            return View(Model);

        }
    }
}