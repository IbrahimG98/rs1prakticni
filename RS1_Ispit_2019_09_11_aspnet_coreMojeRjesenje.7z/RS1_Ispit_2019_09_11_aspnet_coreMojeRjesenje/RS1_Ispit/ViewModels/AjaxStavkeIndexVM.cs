﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class AjaxStavkeIndexVM
    {
        public int PopravniIspitID { get; set; }
        public List<Rows> rows { get; set; }
        public class Rows
        {
            public int PopravniIspitStavkeID { get; set; }
            public string UcenikIme { get; set; }
            public int BrojUDnevniku { get; set; }
            public string Odjeljenje { get; set; }
            public bool Pristupio { get; set; }
            public int? RezultatMaturskog { get; set; }
        }

    }
}
