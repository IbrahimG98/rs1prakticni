﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class PopravniIspitOdaberiVM
    {
        public int PredmetID { get; set; }
        public List<Rows> rows { get; set; }
        public class Rows
        {
            public int PopravniIspitID { get; set; }
            public string Skola { get; set; }
            public string SkolskaGodina { get; set; }
            public string Datum { get; set; }
            public int BrojUcenikaNaPopravnom { get; set; }
            public int BrojUcenikaKojiSuPolozili { get; set; }
        }
    }
}
