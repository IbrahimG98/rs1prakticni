﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RS1_Ispit_asp.net_core.ViewModels
{
    public class AjaxStavkeIndexVM
    {
        public int PopravniIspitID { get; set; }
        
        public List<Rows> rows { get; set; }
        public class Rows
        {
            public int PopravniIspitStavkeID { get; set; }
            public string Ucenik { get; set; }
            public string OdjeljenjeNaziv { get; set; }
            public int BrojUDnevniku { get; set; }
            public bool Pristupio { get; set; }
            public int? RezultatMaturskog { get; set; }

        }
           
    }
}
