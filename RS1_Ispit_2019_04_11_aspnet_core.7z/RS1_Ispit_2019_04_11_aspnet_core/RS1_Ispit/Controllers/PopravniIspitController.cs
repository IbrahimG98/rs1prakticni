﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.ViewModels;
using RS1_Ispit_asp.net_core.EntityModels;
using Microsoft.EntityFrameworkCore;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class PopravniIspitController : Controller
    {
        private MojContext _db;
        public PopravniIspitController(MojContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            PopravniIspitIndexVM Model = new PopravniIspitIndexVM
            {
                rows = _db.Predmet.Select(x => new PopravniIspitIndexVM.Rows
                {
                    PredmetID = x.Id,
                    PredmetNaziv = x.Naziv,
                    Razred = x.Razred
                }).OrderBy(l => l.Razred).ToList()

            };
            return View(Model);
        }
        public IActionResult Odaberi(int predmetid)
        {
            Predmet p = _db.Predmet.Where(x => x.Id == predmetid).FirstOrDefault();
            
            PopravniIspitOdaberiVM Model = new PopravniIspitOdaberiVM
            {
                PredmetID=p.Id,
                rows=_db.PopravniIspit.Where(l=>l.PredmetID==p.Id).Select(g=>new PopravniIspitOdaberiVM.Rows
                {
                    PopravniIspitID=g.ID,
                    DatumIspita=g.Datum.ToShortDateString(),
                    SkolaNaziv=g.Skola.Naziv,
                    SkolskaGodinaNaziv=g.SkolskaGodina.Naziv,
                    Polozili=_db.PopravniIspitStavke.Count(m=>m.PopravniIspitID==g.ID && m.RezultatMaturskog>50),
                    UkupnoNaIspitu= _db.PopravniIspitStavke.Count(m => m.PopravniIspitID == g.ID)

                }).ToList()

            };
            return View(Model);
        }

        public IActionResult Dodaj(int predmetid)
        {
            Predmet p = _db.Predmet.Where(x => x.Id == predmetid).FirstOrDefault();
            PopravniIspitDodajVM Model = new PopravniIspitDodajVM
            {PredmetID=p.Id,
            Razred=p.Razred,
            PredmetNaziv=p.Naziv,
            Skola=_db.Skola.Select(x=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
            {
                Value=x.Id.ToString(),
                Text=x.Naziv
            }).ToList(),
            SkolskaGodina=_db.SkolskaGodina.Select(l=>new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
            {
                Value=l.Id.ToString(),
                Text=l.Naziv
            }).ToList()

            };
            return View(Model);
        }
        public IActionResult Snimi(PopravniIspitDodajVM x)
        {
            PopravniIspit n = new PopravniIspit
            {
                Datum=x.DatumIspita,
                SkolaID=x.SkolaID,
                SkolskaGodinaID=x.SkolskaGodinaID,
                PredmetID=x.PredmetID
                
            };

            _db.PopravniIspit.Add(n);
            _db.SaveChanges();

            foreach(var g in _db.OdjeljenjeStavka.Where(l=>l.Odjeljenje.SkolaID==n.SkolaID && l.Odjeljenje.SkolskaGodinaID==n.SkolskaGodinaID))
            {
                if(_db.DodjeljenPredmet.Where(k=>k.OdjeljenjeStavkaId==g.Id && k.PredmetId==n.PredmetID).Count(l=>l.ZakljucnoKrajGodine==1)>0)
                {
                    PopravniIspitStavke pis = new PopravniIspitStavke
                    {
                        OdjeljenjeStavkaID=g.Id,
                        PopravniIspitID=n.ID,
                        Pristupio=false
                        

                    };

                    if(_db.DodjeljenPredmet.Where(k => k.OdjeljenjeStavkaId == g.Id).Count(l => l.ZakljucnoKrajGodine == 1) > 2)
                    {
                        pis.RezultatMaturskog = 0;
                    }
                    else
                    {
                        pis.RezultatMaturskog = null;
                    }
                    _db.PopravniIspitStavke.Add(pis);
                }
            }
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Odaberi?predmetid="+n.PredmetID);
        }
        public IActionResult Uredi(int PopravniIspitID)
        {
            PopravniIspit p = _db.PopravniIspit.Include(s=>s.Skola).Include(k=>k.Predmet).Include(l=>l.SkolskaGodina).Where(x => x.ID == PopravniIspitID).FirstOrDefault();

            PopravniIspitUrediVM Model = new PopravniIspitUrediVM
            {
                PopravniIspitID=p.ID,
                PredmetID=p.ID,
                DatumIspita=p.Datum.ToShortDateString(),
                SkolaNaziv=p.Skola.Naziv,
                SkolskaGodina=p.SkolskaGodina.Naziv,
                PredmetNaziv=p.Predmet.Naziv,
                Razred=p.Predmet.Razred


            };

            return View(Model);
        }
    }
}