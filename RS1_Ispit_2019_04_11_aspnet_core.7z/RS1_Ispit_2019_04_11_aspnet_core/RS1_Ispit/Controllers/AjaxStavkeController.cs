﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RS1_Ispit_asp.net_core.EF;
using RS1_Ispit_asp.net_core.EntityModels;
using RS1_Ispit_asp.net_core.ViewModels;

namespace RS1_Ispit_asp.net_core.Controllers
{
    public class AjaxStavkeController : Controller
    {
        private MojContext _db;
        public AjaxStavkeController(MojContext db)
        {
            _db = db;
        }

        public IActionResult Index(int PopravniIspitID)
        {
            PopravniIspit p = _db.PopravniIspit.Where(x => x.ID == PopravniIspitID).FirstOrDefault();
            AjaxStavkeIndexVM Model = new AjaxStavkeIndexVM
            {
                PopravniIspitID = p.ID,
                rows = _db.PopravniIspitStavke.Where(x => x.PopravniIspitID == p.ID).Select(k => new AjaxStavkeIndexVM.Rows
                {
                    PopravniIspitStavkeID = k.ID,
                    Ucenik = _db.OdjeljenjeStavka.Where(l => l.Id == k.OdjeljenjeStavkaID).Select(h => h.Ucenik.ImePrezime).FirstOrDefault(),
                    BrojUDnevniku = _db.OdjeljenjeStavka.Where(l => l.Id == k.OdjeljenjeStavkaID).Select(g => g.BrojUDnevniku).FirstOrDefault(),
                    OdjeljenjeNaziv = _db.OdjeljenjeStavka.Where(l => l.Id == k.OdjeljenjeStavkaID).Select(h => h.Odjeljenje.Oznaka).FirstOrDefault(),
                    Pristupio = k.Pristupio,
                    RezultatMaturskog = k.RezultatMaturskog

                }).ToList()
            };
            return View(Model);
        }
        public IActionResult Uredi(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke P = _db.PopravniIspitStavke.Where(x => x.ID == PopravniIspitStavkeID).FirstOrDefault();
            AjaxStavkeUrediVM Model = new AjaxStavkeUrediVM
            {
                PopravniIspitStavkeID=P.ID,
                UcenikImePrezime=_db.OdjeljenjeStavka.Where(x=>x.Id==P.OdjeljenjeStavkaID).Select(k=>k.Ucenik.ImePrezime).FirstOrDefault(),
                RezultatMaturskog=P.RezultatMaturskog

            };
            return PartialView(Model);
        }
        public IActionResult Snimi(AjaxStavkeUrediVM x)
        {
            PopravniIspitStavke d = _db.PopravniIspitStavke.Find(x.PopravniIspitStavkeID);
            d.RezultatMaturskog = x.RezultatMaturskog;
            _db.SaveChanges();

            return Redirect("/PopravniIspit/Uredi?PopravniIspitID="+d.PopravniIspitID);
        }

        public IActionResult JePristupio(int PopravniIspitStavkeID)
        {
            PopravniIspitStavke d = _db.PopravniIspitStavke.Find(PopravniIspitStavkeID);
            d.Pristupio = true;
            _db.SaveChanges();
            return Redirect("/PopravniIspit/Uredi?PopravniIspitID=" + d.PopravniIspitID);
        }
    }
}